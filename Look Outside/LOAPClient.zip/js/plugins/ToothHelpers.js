/**
 * @target MZ
 * @name ToothHelpers
 * @plugindesc Helpers for updating the tooth family events
 * @authors 0palite
 * @version 1.0
 * @license Unlicensed
 * @help
 */

var ToothHelpers = ToothHelpers || {};

// allow mutated version to spawn even if base is dead; 
// only remove when player explicitly triggers recruit
ToothHelpers.JoelPages = [
  {
    conditions: {
      actorId: 1,
      actorValid: false,
      itemId: 1,
      itemValid: false,
      selfSwitchCh: "A",
      selfSwitchValid: false,
      switch1Id: 1,
      switch1Valid: false,
      switch2Id: 1,
      switch2Valid: false,
      variableId: 1,
      variableValid: false,
      variableValue: 0,
    },
    directionFix: true,
    image: {
      tileId: 0,
      characterName: "Chara_Recruit",
      direction: 8,
      pattern: 1,
      characterIndex: 0,
    },
    list: [
      {
        code: 132,
        indent: 0,
        parameters: [
          {
            name: "HeartBeat",
            volume: 90,
            pitch: 100,
            pan: 0,
          },
        ],
      },
      {
        code: 283,
        indent: 0,
        parameters: ["Back_Bathroom", ""],
      },
      {
        code: 301,
        indent: 0,
        parameters: [0, 26, true, false],
      },
      {
        code: 601,
        indent: 0,
        parameters: [],
      },
      {
        code: 123,
        indent: 1,
        parameters: ["A", 0],
      },
      {
        code: 122,
        indent: 1,
        parameters: [26, 26, 1, 0, 1],
      },
      {
        code: 122,
        indent: 1,
        parameters: [116, 116, 1, 0, 10],
      },
      {
        code: 122,
        indent: 1,
        parameters: [541, 541, 1, 0, 1],
      },
      {
        code: 121,
        indent: 1,
        parameters: [541, 541, 0],
      },
      {
        code: 0,
        indent: 1,
        parameters: [],
      },
      {
        code: 602,
        indent: 0,
        parameters: [],
      },
      {
        code: 0,
        indent: 1,
        parameters: [],
      },
      {
        code: 604,
        indent: 0,
        parameters: [],
      },
      {
        code: 283,
        indent: 0,
        parameters: ["Back_Corridor", ""],
      },
      {
        code: 355,
        indent: 0,
        parameters: ["setSybilMajorStory(20);"],
      },
      {
        code: 0,
        indent: 0,
        parameters: [],
      },
    ],
    moveFrequency: 3,
    moveRoute: {
      list: [
        {
          code: 0,
          parameters: [],
        },
      ],
      repeat: true,
      skippable: false,
      wait: false,
    },
    moveSpeed: 3,
    moveType: 0,
    priorityType: 1,
    stepAnime: false,
    through: false,
    trigger: 0,
    walkAnime: false,
  },
  {
    conditions: {
      actorId: 1,
      actorValid: false,
      itemId: 1,
      itemValid: false,
      selfSwitchCh: "A",
      selfSwitchValid: false,
      switch1Id: 1,
      switch1Valid: false,
      switch2Id: 1,
      switch2Valid: false,
      variableId: 107,
      variableValid: true,
      variableValue: 6,
    },
    directionFix: false,
    image: {
      tileId: 0,
      characterName: "Chara_Recruit",
      direction: 2,
      pattern: 1,
      characterIndex: 0,
    },
    list: [
      {
        code: 132,
        indent: 0,
        parameters: [
          {
            name: "Fight",
            volume: 90,
            pitch: 100,
            pan: 0,
          },
        ],
      },
      {
        code: 283,
        indent: 0,
        parameters: ["Back_Bathroom", ""],
      },
      {
        code: 301,
        indent: 0,
        parameters: [0, 26, true, false],
      },
      {
        code: 601,
        indent: 0,
        parameters: [],
      },
      {
        code: 123,
        indent: 1,
        parameters: ["A", 0],
      },
      {
        code: 122,
        indent: 1,
        parameters: [26, 26, 1, 0, 1],
      },
      {
        code: 122,
        indent: 1,
        parameters: [116, 116, 1, 0, 10],
      },
      {
        code: 122,
        indent: 1,
        parameters: [541, 541, 1, 0, 1],
      },
      {
        code: 121,
        indent: 1,
        parameters: [541, 541, 0],
      },
      {
        code: 0,
        indent: 1,
        parameters: [],
      },
      {
        code: 602,
        indent: 0,
        parameters: [],
      },
      {
        code: 0,
        indent: 1,
        parameters: [],
      },
      {
        code: 604,
        indent: 0,
        parameters: [],
      },
      {
        code: 283,
        indent: 0,
        parameters: ["Back_Corridor", ""],
      },
      {
        code: 0,
        indent: 0,
        parameters: [],
      },
    ],
    moveFrequency: 3,
    moveRoute: {
      list: [
        {
          code: 9,
          indent: null,
        },
        {
          code: 9,
          indent: null,
        },
        {
          code: 10,
          indent: null,
        },
        {
          code: 9,
          indent: null,
        },
        {
          code: 9,
          indent: null,
        },
        {
          code: 10,
          indent: null,
        },
        {
          code: 9,
          indent: null,
        },
        {
          code: 10,
          indent: null,
        },
        {
          code: 9,
          indent: null,
        },
        {
          code: 10,
          indent: null,
        },
        {
          code: 10,
          indent: null,
        },
        {
          code: 10,
          indent: null,
        },
        {
          code: 0,
          parameters: [],
        },
      ],
      repeat: true,
      skippable: false,
      wait: false,
    },
    moveSpeed: 3,
    moveType: 3,
    priorityType: 1,
    stepAnime: false,
    through: false,
    trigger: 0,
    walkAnime: false,
  },
  {
    conditions: {
      actorId: 1,
      actorValid: false,
      itemId: 1,
      itemValid: false,
      selfSwitchCh: "A",
      selfSwitchValid: false,
      switch1Id: 1,
      switch1Valid: false,
      switch2Id: 1,
      switch2Valid: false,
      variableId: 107,
      variableValid: true,
      variableValue: 8,
    },
    directionFix: false,
    image: {
      tileId: 0,
      characterName: "Chara_Recruit",
      direction: 2,
      pattern: 1,
      characterIndex: 0,
    },
    list: [
      {
        code: 132,
        indent: 0,
        parameters: [
          {
            name: "HeartBeat",
            volume: 90,
            pitch: 100,
            pan: 0,
          },
        ],
      },
      {
        code: 283,
        indent: 0,
        parameters: ["Back_Bathroom", ""],
      },
      {
        code: 301,
        indent: 0,
        parameters: [0, 26, true, false],
      },
      {
        code: 601,
        indent: 0,
        parameters: [],
      },
      {
        code: 123,
        indent: 1,
        parameters: ["A", 0],
      },
      {
        code: 122,
        indent: 1,
        parameters: [26, 26, 1, 0, 1],
      },
      {
        code: 122,
        indent: 1,
        parameters: [116, 116, 1, 0, 10],
      },
      {
        code: 122,
        indent: 1,
        parameters: [541, 541, 1, 0, 1],
      },
      {
        code: 121,
        indent: 1,
        parameters: [541, 541, 0],
      },
      {
        code: 0,
        indent: 1,
        parameters: [],
      },
      {
        code: 602,
        indent: 0,
        parameters: [],
      },
      {
        code: 0,
        indent: 1,
        parameters: [],
      },
      {
        code: 604,
        indent: 0,
        parameters: [],
      },
      {
        code: 283,
        indent: 0,
        parameters: ["Back_Corridor", ""],
      },
      {
        code: 0,
        indent: 0,
        parameters: [],
      },
    ],
    moveFrequency: 3,
    moveRoute: {
      list: [
        {
          code: 9,
          indent: null,
        },
        {
          code: 9,
          indent: null,
        },
        {
          code: 10,
          indent: null,
        },
        {
          code: 9,
          indent: null,
        },
        {
          code: 9,
          indent: null,
        },
        {
          code: 10,
          indent: null,
        },
        {
          code: 9,
          indent: null,
        },
        {
          code: 10,
          indent: null,
        },
        {
          code: 9,
          indent: null,
        },
        {
          code: 10,
          indent: null,
        },
        {
          code: 10,
          indent: null,
        },
        {
          code: 10,
          indent: null,
        },
        {
          code: 0,
          parameters: [],
        },
      ],
      repeat: true,
      skippable: false,
      wait: false,
    },
    moveSpeed: 3,
    moveType: 0,
    priorityType: 1,
    stepAnime: false,
    through: false,
    trigger: 0,
    walkAnime: false,
  },
  {
    conditions: {
      actorId: 1,
      actorValid: false,
      itemId: 1,
      itemValid: false,
      selfSwitchCh: "A",
      selfSwitchValid: true,
      switch1Id: 1,
      switch1Valid: false,
      switch2Id: 1,
      switch2Valid: false,
      variableId: 107,
      variableValid: false,
      variableValue: 6,
    },
    directionFix: false,
    image: {
      tileId: 0,
      characterName: "Chara_Zombies",
      direction: 6,
      pattern: 2,
      characterIndex: 7,
    },
    list: [
      {
        code: 0,
        indent: 0,
        parameters: [],
      },
    ],
    moveFrequency: 3,
    moveRoute: {
      list: [
        {
          code: 0,
          parameters: [],
        },
      ],
      repeat: true,
      skippable: false,
      wait: false,
    },
    moveSpeed: 3,
    moveType: 0,
    priorityType: 0,
    stepAnime: false,
    through: false,
    trigger: 0,
    walkAnime: true,
  },
  {
    conditions: {
      actorId: 1,
      actorValid: false,
      itemId: 1,
      itemValid: false,
      selfSwitchCh: "A",
      selfSwitchValid: false,
      switch1Id: 784,
      switch1Valid: true,
      switch2Id: 1,
      switch2Valid: false,
      variableId: 1,
      variableValid: false,
      variableValue: 0,
    },
    directionFix: false,
    image: {
      characterIndex: 0,
      characterName: "",
      direction: 2,
      pattern: 0,
      tileId: 0,
    },
    list: [
      {
        code: 0,
        indent: 0,
        parameters: [],
      },
    ],
    moveFrequency: 3,
    moveRoute: {
      list: [
        {
          code: 0,
          parameters: [],
        },
      ],
      repeat: true,
      skippable: false,
      wait: false,
    },
    moveSpeed: 3,
    moveType: 0,
    priorityType: 0,
    stepAnime: false,
    through: false,
    trigger: 0,
    walkAnime: true,
  },
  {
    conditions: {
      actorId: 1,
      actorValid: false,
      itemId: 1,
      itemValid: false,
      selfSwitchCh: "A",
      selfSwitchValid: false,
      switch1Id: 1,
      switch1Valid: false,
      switch2Id: 1,
      switch2Valid: false,
      variableId: 15,
      variableValid: true,
      variableValue: 4,
    },
    directionFix: false,
    image: {
      tileId: 0,
      characterName: "Encounters_Huge8",
      direction: 6,
      pattern: 1,
      characterIndex: 1,
    },
    list: [
      {
        code: 132,
        indent: 0,
        parameters: [
          {
            name: "HeartBeat",
            volume: 90,
            pitch: 100,
            pan: 0,
          },
        ],
      },
      {
        code: 283,
        indent: 0,
        parameters: ["Back_Bathroom", ""],
      },
      {
        code: 301,
        indent: 0,
        parameters: [0, 740, true, false],
      },
      {
        code: 601,
        indent: 0,
        parameters: [],
      },
      {
        code: 123,
        indent: 1,
        parameters: ["B", 0],
      },
      {
        code: 122,
        indent: 1,
        parameters: [26, 26, 1, 0, 2],
      },
      {
        code: 122,
        indent: 1,
        parameters: [116, 116, 1, 0, 15],
      },
      {
        code: 121,
        indent: 1,
        parameters: [541, 541, 0],
      },
      {
        code: 0,
        indent: 1,
        parameters: [],
      },
      {
        code: 602,
        indent: 0,
        parameters: [],
      },
      {
        code: 0,
        indent: 1,
        parameters: [],
      },
      {
        code: 604,
        indent: 0,
        parameters: [],
      },
      {
        code: 283,
        indent: 0,
        parameters: ["Back_Corridor", ""],
      },
      {
        code: 0,
        indent: 0,
        parameters: [],
      },
    ],
    moveFrequency: 3,
    moveRoute: {
      list: [
        {
          code: 9,
          indent: null,
        },
        {
          code: 9,
          indent: null,
        },
        {
          code: 10,
          indent: null,
        },
        {
          code: 9,
          indent: null,
        },
        {
          code: 9,
          indent: null,
        },
        {
          code: 10,
          indent: null,
        },
        {
          code: 9,
          indent: null,
        },
        {
          code: 10,
          indent: null,
        },
        {
          code: 9,
          indent: null,
        },
        {
          code: 10,
          indent: null,
        },
        {
          code: 10,
          indent: null,
        },
        {
          code: 10,
          indent: null,
        },
        {
          code: 0,
          parameters: [],
        },
      ],
      repeat: true,
      skippable: false,
      wait: false,
    },
    moveSpeed: 3,
    moveType: 0,
    priorityType: 1,
    stepAnime: false,
    through: false,
    trigger: 0,
    walkAnime: false,
  },
  {
    conditions: {
      actorId: 1,
      actorValid: false,
      itemId: 1,
      itemValid: false,
      selfSwitchCh: "B",
      selfSwitchValid: true,
      switch1Id: 1,
      switch1Valid: false,
      switch2Id: 1,
      switch2Valid: false,
      variableId: 15,
      variableValid: true,
      variableValue: 4,
    },
    directionFix: true,
    image: {
      tileId: 0,
      characterName: "Encounters_Huge8",
      direction: 6,
      pattern: 1,
      characterIndex: 3,
    },
    list: [
      {
        code: 0,
        indent: 0,
        parameters: [],
      },
    ],
    moveFrequency: 3,
    moveRoute: {
      list: [
        {
          code: 0,
          parameters: [],
        },
      ],
      repeat: true,
      skippable: false,
      wait: false,
    },
    moveSpeed: 3,
    moveType: 0,
    priorityType: 0,
    stepAnime: false,
    through: false,
    trigger: 0,
    walkAnime: false,
  },
];

ToothHelpers.MadisonPages = [
  {
    conditions: {
      actorId: 1,
      actorValid: false,
      itemId: 1,
      itemValid: false,
      selfSwitchCh: "A",
      selfSwitchValid: false,
      switch1Id: 94,
      switch1Valid: false,
      switch2Id: 1,
      switch2Valid: false,
      variableId: 6,
      variableValid: false,
      variableValue: 120,
    },
    directionFix: true,
    image: {
      tileId: 0,
      characterName: "Chara_Zombies",
      direction: 8,
      pattern: 1,
      characterIndex: 2,
    },
    list: [
      {
        code: 108,
        indent: 0,
        parameters: ["Wander"],
      },
      {
        code: 301,
        indent: 0,
        parameters: [0, 28, true, false],
      },
      {
        code: 601,
        indent: 0,
        parameters: [],
      },
      {
        code: 123,
        indent: 1,
        parameters: ["C", 0],
      },
      {
        code: 122,
        indent: 1,
        parameters: [26, 26, 1, 0, 3],
      },
      {
        code: 122,
        indent: 1,
        parameters: [116, 116, 1, 0, 30],
      },
      {
        code: 122,
        indent: 1,
        parameters: [541, 541, 1, 0, 1],
      },
      {
        code: 121,
        indent: 1,
        parameters: [543, 543, 0],
      },
      {
        code: 0,
        indent: 1,
        parameters: [],
      },
      {
        code: 602,
        indent: 0,
        parameters: [],
      },
      {
        code: 123,
        indent: 1,
        parameters: ["B", 0],
      },
      {
        code: 0,
        indent: 1,
        parameters: [],
      },
      {
        code: 604,
        indent: 0,
        parameters: [],
      },
      {
        code: 0,
        indent: 0,
        parameters: [],
      },
    ],
    moveFrequency: 4,
    moveRoute: {
      list: [
        {
          code: 9,
          indent: null,
        },
        {
          code: 9,
          indent: 0,
        },
        {
          code: 15,
          parameters: [30],
          indent: null,
        },
        {
          code: 45,
          parameters: ["if(this.qPrx(4)){this.sOn('A');}"],
          indent: null,
        },
        {
          code: 0,
          parameters: [],
        },
      ],
      repeat: true,
      skippable: true,
      wait: false,
    },
    moveSpeed: 4,
    moveType: 3,
    priorityType: 1,
    stepAnime: false,
    through: false,
    trigger: 2,
    walkAnime: true,
  },
  {
    conditions: {
      actorId: 1,
      actorValid: false,
      itemId: 1,
      itemValid: false,
      selfSwitchCh: "A",
      selfSwitchValid: true,
      switch1Id: 1,
      switch1Valid: false,
      switch2Id: 1,
      switch2Valid: false,
      variableId: 1,
      variableValid: false,
      variableValue: 0,
    },
    directionFix: true,
    image: {
      tileId: 0,
      characterName: "Chara_Zombies",
      direction: 8,
      pattern: 1,
      characterIndex: 2,
    },
    list: [
      {
        code: 108,
        indent: 0,
        parameters: ["Chase"],
      },
      {
        code: 301,
        indent: 0,
        parameters: [0, 28, true, false],
      },
      {
        code: 601,
        indent: 0,
        parameters: [],
      },
      {
        code: 123,
        indent: 1,
        parameters: ["C", 0],
      },
      {
        code: 122,
        indent: 1,
        parameters: [26, 26, 1, 0, 3],
      },
      {
        code: 122,
        indent: 1,
        parameters: [116, 116, 1, 0, 30],
      },
      {
        code: 122,
        indent: 1,
        parameters: [541, 541, 1, 0, 1],
      },
      {
        code: 121,
        indent: 1,
        parameters: [543, 543, 0],
      },
      {
        code: 0,
        indent: 1,
        parameters: [],
      },
      {
        code: 602,
        indent: 0,
        parameters: [],
      },
      {
        code: 123,
        indent: 1,
        parameters: ["B", 0],
      },
      {
        code: 0,
        indent: 1,
        parameters: [],
      },
      {
        code: 604,
        indent: 0,
        parameters: [],
      },
      {
        code: 0,
        indent: 0,
        parameters: [],
      },
    ],
    moveFrequency: 5,
    moveRoute: {
      list: [
        {
          code: 10,
          indent: null,
        },
        {
          code: 10,
          indent: null,
        },
        {
          code: 10,
          indent: null,
        },
        {
          code: 10,
          indent: null,
        },
        {
          code: 10,
          indent: null,
        },
        {
          code: 10,
          indent: null,
        },
        {
          code: 10,
          indent: null,
        },
        {
          code: 10,
          indent: null,
        },
        {
          code: 45,
          parameters: ["this.sOff('A');"],
          indent: null,
        },
        {
          code: 0,
          parameters: [],
        },
      ],
      repeat: false,
      skippable: true,
      wait: false,
    },
    moveSpeed: 5,
    moveType: 3,
    priorityType: 1,
    stepAnime: false,
    through: false,
    trigger: 2,
    walkAnime: true,
  },
  {
    conditions: {
      actorId: 1,
      actorValid: false,
      itemId: 1,
      itemValid: false,
      selfSwitchCh: "B",
      selfSwitchValid: true,
      switch1Id: 1,
      switch1Valid: false,
      switch2Id: 1,
      switch2Valid: false,
      variableId: 1,
      variableValid: false,
      variableValue: 0,
    },
    directionFix: true,
    image: {
      tileId: 0,
      characterName: "Chara_Zombies",
      direction: 8,
      pattern: 1,
      characterIndex: 2,
    },
    list: [
      {
        code: 108,
        indent: 0,
        parameters: ["Blinking post escape"],
      },
      {
        code: 0,
        indent: 0,
        parameters: [],
      },
    ],
    moveFrequency: 4,
    moveRoute: {
      list: [
        {
          code: 39,
          indent: null,
        },
        {
          code: 15,
          parameters: [15],
          indent: null,
        },
        {
          code: 40,
          indent: null,
        },
        {
          code: 15,
          parameters: [15],
          indent: null,
        },
        {
          code: 39,
          indent: null,
        },
        {
          code: 15,
          parameters: [15],
          indent: 0,
        },
        {
          code: 40,
          indent: null,
        },
        {
          code: 15,
          parameters: [15],
          indent: 0,
        },
        {
          code: 39,
          indent: null,
        },
        {
          code: 15,
          parameters: [15],
          indent: null,
        },
        {
          code: 40,
          indent: null,
        },
        {
          code: 15,
          parameters: [15],
          indent: 0,
        },
        {
          code: 45,
          parameters: ["this.sOff('B');"],
          indent: null,
        },
        {
          code: 0,
          parameters: [],
        },
      ],
      repeat: false,
      skippable: false,
      wait: false,
    },
    moveSpeed: 4,
    moveType: 3,
    priorityType: 1,
    stepAnime: false,
    through: false,
    trigger: 0,
    walkAnime: true,
  },
  {
    conditions: {
      actorId: 1,
      actorValid: false,
      itemId: 1,
      itemValid: false,
      selfSwitchCh: "C",
      selfSwitchValid: true,
      switch1Id: 1,
      switch1Valid: false,
      switch2Id: 1,
      switch2Valid: false,
      variableId: 1,
      variableValid: false,
      variableValue: 0,
    },
    directionFix: false,
    image: {
      tileId: 0,
      characterName: "Chara_Zombies",
      direction: 8,
      pattern: 2,
      characterIndex: 3,
    },
    list: [
      {
        code: 0,
        indent: 0,
        parameters: [],
      },
    ],
    moveFrequency: 3,
    moveRoute: {
      list: [
        {
          code: 0,
          parameters: [],
        },
      ],
      repeat: true,
      skippable: false,
      wait: false,
    },
    moveSpeed: 3,
    moveType: 0,
    priorityType: 0,
    stepAnime: false,
    through: false,
    trigger: 0,
    walkAnime: true,
  },
  {
    conditions: {
      actorId: 1,
      actorValid: false,
      itemId: 1,
      itemValid: false,
      selfSwitchCh: "A",
      selfSwitchValid: false,
      switch1Id: 94,
      switch1Valid: false,
      switch2Id: 1,
      switch2Valid: false,
      variableId: 15,
      variableValid: true,
      variableValue: 4,
    },
    directionFix: true,
    image: {
      tileId: 0,
      characterName: "Encounters_Huge8",
      direction: 2,
      pattern: 1,
      characterIndex: 4,
    },
    list: [
      {
        code: 108,
        indent: 0,
        parameters: ["Wander"],
      },
      {
        code: 301,
        indent: 0,
        parameters: [0, 738, true, false],
      },
      {
        code: 601,
        indent: 0,
        parameters: [],
      },
      {
        code: 123,
        indent: 1,
        parameters: ["D", 0],
      },
      {
        code: 122,
        indent: 1,
        parameters: [26, 26, 1, 0, 3],
      },
      {
        code: 122,
        indent: 1,
        parameters: [116, 116, 1, 0, 30],
      },
      {
        code: 122,
        indent: 1,
        parameters: [541, 541, 1, 0, 1],
      },
      {
        code: 121,
        indent: 1,
        parameters: [543, 543, 0],
      },
      {
        code: 0,
        indent: 1,
        parameters: [],
      },
      {
        code: 602,
        indent: 0,
        parameters: [],
      },
      {
        code: 123,
        indent: 1,
        parameters: ["B", 0],
      },
      {
        code: 0,
        indent: 1,
        parameters: [],
      },
      {
        code: 604,
        indent: 0,
        parameters: [],
      },
      {
        code: 0,
        indent: 0,
        parameters: [],
      },
    ],
    moveFrequency: 4,
    moveRoute: {
      list: [
        {
          code: 9,
          indent: null,
        },
        {
          code: 9,
          indent: 0,
        },
        {
          code: 15,
          parameters: [30],
          indent: null,
        },
        {
          code: 45,
          parameters: ["if(this.qPrx(4)){this.sOn('A');}"],
          indent: null,
        },
        {
          code: 0,
          parameters: [],
        },
      ],
      repeat: true,
      skippable: true,
      wait: false,
    },
    moveSpeed: 4,
    moveType: 3,
    priorityType: 1,
    stepAnime: false,
    through: false,
    trigger: 2,
    walkAnime: true,
  },
  {
    conditions: {
      actorId: 1,
      actorValid: false,
      itemId: 1,
      itemValid: false,
      selfSwitchCh: "D",
      selfSwitchValid: true,
      switch1Id: 1,
      switch1Valid: false,
      switch2Id: 1,
      switch2Valid: false,
      variableId: 15,
      variableValid: true,
      variableValue: 4,
    },
    directionFix: false,
    image: {
      tileId: 0,
      characterName: "Encounters_Huge8",
      direction: 2,
      pattern: 0,
      characterIndex: 7,
    },
    list: [
      {
        code: 0,
        indent: 0,
        parameters: [],
      },
    ],
    moveFrequency: 3,
    moveRoute: {
      list: [
        {
          code: 0,
          parameters: [],
        },
      ],
      repeat: true,
      skippable: false,
      wait: false,
    },
    moveSpeed: 3,
    moveType: 0,
    priorityType: 0,
    stepAnime: false,
    through: false,
    trigger: 0,
    walkAnime: true,
  },
];
